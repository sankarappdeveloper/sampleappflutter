import 'package:flutter/material.dart';

const Primarycolor = Color(0xffabadaf);
const Primarycolor2 = Color(0xfff0f2f3);
const Primarycolor3 = Color(0xFF6ab854);
const Secondarycolor = Color(0xFFEB1858);
const Accentcolor = Color(0xFF2A1D42);
const Accentcolor1 = Color(0xFF2A1D42);
const Accentc = Color(0xff1b6ef5);
const LightGray = Color(0xffebebeb);
const LightGray2 = Color(0xfff2f2f2);
const LightGray3 = Color(0xffcfcfcf);
const LightGray4 = Color(0xFFf1f2f3);
const LightGray5 = Color(0xFFebebeb);
const LightGray6 = Color(0xFF607d8b);
const Lightred = Color(0xFFd9534f);




const Buttoncolor = Color(0xFF51d8a6);
const Busycolor = Color(0xFFe0e5fe);
const BusyDarkcolor = Color(0xFFbbc5e6);
const Pendingcolor = Color(0xFFfde1e4);
const PendingDarkcolor = Color(0xFFdbaeaf);


