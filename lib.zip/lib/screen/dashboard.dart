import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:waiterapp/screen/cartpage.dart';
import 'package:waiterapp/utils/custom_color.dart';

import '../utils/circle_painter.dart';

//Class must be in Uppercase
//Landing page after signin

class Dashboard extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _Dashboard();
}

class _Dashboard extends State<Dashboard> {


  // Variable declaration must be lowerCamelCase
  final List<Map> myProducts = List.generate(
          12, (index) => {"id": index.toString(), "name": "Product $index"})
      .toList();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(

        body: SafeArea(child:Container(
          margin: const EdgeInsets.all(12),
            child: Column(children: [


              Padding(padding: const EdgeInsets.all(5),child: Row(

                children: [

                  Text("My Table",style: TextStyle(fontSize: 25,fontWeight: FontWeight.w700),)

                ],

              ),
              ),



              Container(
            decoration: BoxDecoration(
color: Colors.white,
              border: Border.all(color: Colors.grey)
            ),
                margin: const EdgeInsets.all(15),
              child:Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 20,),
                  Padding(padding: const EdgeInsets.all(5),child:Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(width: 20,),



                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CustomPaint(
                        painter: CirclePainter(pendingdarkcolor),
                      ),
                    ),
                      SizedBox(width: 5),
                      Text(
                        "5 ",
                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                      ),
                      Text("Order Pending "),

                      SizedBox(width: 20,),
                    ],
                  )),
                  SizedBox(width: 20,),

                  Padding(padding: const EdgeInsets.all(5),child:Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      SizedBox(
                        width: 20,
                        height: 20,
                        child: CustomPaint(
                          painter: CirclePainter(busydarkcolor),
                        ),
                      ),
                      SizedBox(width: 5),
                      Text(
                        "4  ",
                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                      ),
                      Text("Table busy")
                    ],
                  ),),

                ],
              ),
              ),

          Expanded(
              child: Padding(
                  padding: const EdgeInsets.only(left:15,right: 15),
                  child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                      ),
                      itemCount: DUMMY_Tables.length,
                      itemBuilder: (BuildContext ctx, index) {
                        return InkWell(onTap: ()
                          {

                            if(DUMMY_Tables[index].status=='0') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Cartpage()),
                              );
                            }
                          },child:Padding(
                            padding: const EdgeInsets.all(5),
                            child: Container(
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    color: DUMMY_Tables[index].status == '0'
                                        ? Colors.white
                                        : DUMMY_Tables[index].status == "1"
                                            ? pendingdarkcolor
                                            : busydarkcolor,
                                    border: DUMMY_Tables[index].status == '0'
                                        ? Border.all(color: Colors.grey)
                                        : DUMMY_Tables[index].status == "1"
                                            ? Border.all(
                                                color: pendingcolor)
                                            : Border.all(
                                                color: busycolor),
                                    borderRadius: BorderRadius.circular(15)),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      DUMMY_Tables[index].tabno,
                                      style: TextStyle(
                                          fontSize: 30,
                                          fontWeight: FontWeight.bold),
                                    ),Text(
                                      DUMMY_Tables[index].count+" Seats",
                                      style: TextStyle(
                                          fontSize: 15,
                                          ),
                                    ),
                                  ],
                                ))));
                      })))
        ]))));
  }
}

const DUMMY_Tables = const [
  Tabledata(id: "1", tabno: "1", count: "3", status: "0"),
  Tabledata(id: "2", tabno: "2", count: "2", status: "1"),
  Tabledata(id: "3", tabno: "3", count: "3", status: "0"),
  Tabledata(id: "4", tabno: "4", count: "4", status: "2"),
  Tabledata(id: "5", tabno: "5", count: "3", status: "0"),
  Tabledata(id: "6", tabno: "6", count: "6", status: "0"),
  Tabledata(id: "7", tabno: "7", count: "3", status: "0"),
  Tabledata(id: "8", tabno: "8", count: "3", status: "1"),
  Tabledata(id: "9", tabno: "9", count: "4", status: "0"),
  Tabledata(id: "10", tabno: "10", count: "2", status: "0"),
  Tabledata(id: "11", tabno: "11", count: "4", status: "1"),
  Tabledata(id: "12", tabno: "12", count: "2", status: "0")

  /*APPOINTMENT(date: 'Tomorrow', time: '04:00 PM'),
  APPOINTMENT(date: 'Jan 26', time: '04:00 PM'),*/
];

class Tabledata {
  final String id;
  final String tabno;
  final String count;
  final String status;

  const Tabledata(
      {required this.id,
      required this.tabno,
      required this.count,
      required this.status});
}
