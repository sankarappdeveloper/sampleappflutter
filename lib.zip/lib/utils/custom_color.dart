import 'package:flutter/material.dart';





// Variable declaration must be lowerCamelCase
const buttoncolor = Color(0xFF51d8a6);
const busycolor = Color(0xFFe0e5fe);
const busydarkcolor = Color(0xFFbbc5e6);
const pendingcolor = Color(0xFFfde1e4);
const pendingdarkcolor = Color(0xFFdbaeaf);


