import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Cartpage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _Cartpage();
}

class _Cartpage extends State<Cartpage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        body: SafeArea(child:Column(children: [
      Container(
        margin: const EdgeInsets.all(15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(5),
              child: Row(
                children: [
                  Text(
                    "Table 1",
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700),
                  )
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.all(20),
              child: TextField(
                //controller: _controller,

                cursorColor: Colors.greenAccent,
                decoration: InputDecoration(

                    suffixIcon: Icon(Icons.search),
                    isDense: true,
                    hintText: "Search Items",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0))),
              ),
            ),
          ],
        ),
      ),
      Expanded(
          child: Container(
        child: ListView.builder(
          itemCount: DUMMY_items.length,
          itemBuilder: (context, position) {
            return  Container(
                color: Colors.white,
                child:Column(
              children: [
                Padding(padding: const EdgeInsets.all(10),child:Row(
                  children: [
                    Text(DUMMY_items[position].name),
                    Expanded(child: Container()),
                    Text("Rs :"+DUMMY_items[position].amount),
                  ],
                ),),
                // Divider()
              ],)
            );
          },
        ),
      ))
    ])));
  }
}

const DUMMY_items = const [
  Items(id: "1", name: "Chicker Briyani", amount: "150"),
  Items(id: "2", name: "Mutton Briyani", amount: "200"),
  Items(id: "3", name: "Parotta", amount: "300"),
  Items(id: "4", name: "Kari Dosa", amount: "400"),
  Items(id: "5", name: "Fish Briyani", amount: "300"),
  Items(id: "6", name: "Chicken Fried Rice", amount: "600"),
  Items(id: "7", name: "Mandi Briyani", amount: "300"),
  Items(id: "8", name: "Chicken Lollipop", amount: "300"),
  Items(id: "9", name: "Chilly chicken", amount: "400"),
  Items(id: "10", name: "Chicker Briyani", amount: "200"),
  Items(id: "11", name: "Chicker Briyani", amount: "400"),
  Items(id: "12", name: "Chicker Briyani", amount: "200")

  /*APPOINTMENT(date: 'Tomorrow', time: '04:00 PM'),
  APPOINTMENT(date: 'Jan 26', time: '04:00 PM'),*/
];

class Items {
  final String id;
  final String name;
  final String amount;

  const Items({required this.id, required this.name, required this.amount});
}
